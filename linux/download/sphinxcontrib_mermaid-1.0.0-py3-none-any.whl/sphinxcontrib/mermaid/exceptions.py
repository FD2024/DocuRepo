from sphinx.errors import SphinxError


class MermaidError(SphinxError):
    category = "Mermaid error"
